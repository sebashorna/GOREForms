import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CrearSaludDTO } from '../models/crear-salud.dto';

@Injectable({
  providedIn: 'root'
})
export class SaludService {

  private http = inject(HttpClient);

  private api = 'http://localhost:3000/api/salud';

  obtenerEstablecimiento(id: number): Observable<any> {

    return this.http.get<any>(
      `${this.api}/establecimiento/${id}`
    );

  }

  guardarReporteSalud(dto: CrearSaludDTO): Observable<any> {

    return this.http.post<any>(
      this.api,
      dto
    );

  }

}