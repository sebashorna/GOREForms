import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

import { SaludService } from '../../services/salud';
import { CrearSaludDTO } from '../../models/crear-salud.dto';

@Component({
  selector: 'app-salud',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './salud.html',
  styleUrl: './salud.css',
})
export class Salud {
  private fb = inject(FormBuilder);
  private saludService = inject(SaludService);

  form = this.fb.group({
    //==============================
    // INFORMACIÓN GENERAL
    //==============================

    id_renaes: ['', [Validators.required, Validators.pattern(/^\d{8}$/)]],

    nombre_eess: [''],

    categoria: [''],

    red_salud: [''],

    microred: [''],

    provincia: [''],

    distrito: [''],

    tipo: [''],

    coord_lat: [0],

    coord_long: [0],

    poblacion_asignada: [0],

    //==============================
    // PROYECTO DE INVERSIÓN
    //==============================

    id_proyecto: [0],

    estado_inversion: [''],

    avance_fisico: [0, [Validators.min(0), Validators.max(100)]],

    avance_financiero: [0, [Validators.min(0), Validators.max(100)]],

    monto_total: [0],

    monto_devengado: [0],

    unidad_ejecutora: [''],

    //==============================
    // EQUIPAMIENTO
    //==============================

    camas_uci_tot: [0],

    camas_uci_disp: [0],

    camas_hospitalarias: [0],

    equipo_rayos_x: [false],

    planta_oxigeno: [false],

    estado_infra: [1, [Validators.min(1), Validators.max(5)]],

    ventiladores: [0],

    monitores: [0],

    ecografo: [false],

    tomografo: [false],

    operativo: [0],

    inoperativo: [0],

    //==============================
    // RECURSOS HUMANOS
    //==============================

    med_prog: [0],

    med_exist: [0],

    turno_24h: [false],

    enfermeras: [0],

    tecnicos: [0],

    pediatra: [0],

    gineco_obstetra: [0],

    anestesiologo: [0],

    cirujano_general: [0],

    intensivista: [0],

    internista: [0],

    cardiologo: [0],

    traumatologo: [0],

    otros_especialistas: [0],

    //==============================
    // EPIDEMIOLOGÍA
    //==============================

    anho_epi: [new Date().getFullYear()],

    semana_epi: [1, [Validators.min(1), Validators.max(53)]],

    casos_dengue: [0],

    casos_anemia: [0],

    mort_materna: [0],

    casos_desnutricion: [0],

    iras_edas: [0],

    mortalidad_neonatal: [0],

    //==============================
    // SERVICIOS
    //==============================

    emergencia: [false],

    uci: [false],

    centro_quirurgico: [false],

    partos: [false],

    consultas_diarias_prom: [0],

    camas_ocupadas: [0],

    //==============================
    // CONDICIONES BÁSICAS
    //==============================

    agua: [false],

    desague: [false],

    electricidad: [false],

    oxigeno: [false],

    internet: [false],

    //==============================
    // FECHA
    //==============================

    fecha_corte: ['', Validators.required],
  });

  buscarEstablecimiento(): void {
    const id = Number(this.form.get('id_renaes')?.value);

    if (!id) return;

    this.saludService
      .obtenerEstablecimiento(id)

      .subscribe({
        next: (resp) => {
          console.log(resp);

          if (!resp.success || !resp.data) {
            alert('No existe el establecimiento.');

            return;
          }

          this.form.patchValue({
            nombre_eess: resp.data.nombre_eess,

            categoria: resp.data.categoria,

            red_salud: resp.data.red_salud,

            microred: resp.data.microred,

            provincia: resp.data.provincia,

            distrito: resp.data.distrito,

            tipo: resp.data.tipo,

            coord_lat: Number(resp.data.coord_lat),

            coord_long: Number(resp.data.coord_long),

            poblacion_asignada: resp.data.poblacion_asignada,
          });
        },

        error: (err) => {
          console.error(err);

          alert('Error al consultar el establecimiento.');
        },
      });
  }

  guardarReporte(): void {
  // //   if (this.form.invalid) {
  // //     this.form.markAllAsTouched();
  // //     alert("Complete los campos obligatorios.");
  // //     return;
  // //   }

  // //   const rawValues = this.form.getRawValue();

  // //   // Construcción del objeto adaptado estrictamente a tu interfaz CrearSaludDTO plana
  // //   const dto: CrearSaludDTO = {
  // //     // Información General
  // //     id_renaes: Number(rawValues.id_renaes),
  // //     poblacion_asignada: Number(rawValues.poblacion_asignada),
  // //     coord_lat: Number(rawValues.coord_lat),
  // //     coord_long: Number(rawValues.coord_long),

  // //     // Proyectos
  // //     estado_inversion: rawValues.estado_inversion || '',
  // //     avance_fisico: Number(rawValues.avance_fisico),
  // //     avance_financiero: Number(rawValues.avance_financiero),
  // //     monto_total: Number(rawValues.monto_total),
  // //     monto_devengado: Number(rawValues.monto_devengado),
  // //     unidad_ejecutora: rawValues.unidad_ejecutora || '',

  // //     // Equipamiento
  // //     camas_uci_tot: Number(rawValues.camas_uci_tot),
  // //     camas_uci_disp: Number(rawValues.camas_uci_disp),
  // //     camas_hospitalarias: Number(rawValues.camas_hospitalarias),
  // //     equipo_rayos_x: Boolean(rawValues.equipo_rayos_x),
  // //     planta_oxigeno: Boolean(rawValues.planta_oxigeno),
  // //     estado_infra: Number(rawValues.estado_infra),
  // //     ventiladores: Number(rawValues.ventiladores),
  // //     monitores: Number(rawValues.monitores),
  // //     ecografo: Boolean(rawValues.ecografo),
  // //     tomografo: Boolean(rawValues.tomografo),
  // //     operativo: Number(rawValues.operativo),
  // //     inoperativo: Number(rawValues.inoperativo),

  // //     // Recursos Humanos (brecha_med eliminada porque se calcula en PostgreSQL)
  // //     med_prog: Number(rawValues.med_prog),
  // //     med_exist: Number(rawValues.med_exist),
  // //     turno_24h: Boolean(rawValues.turno_24h),
  // //     enfermeras: Number(rawValues.enfermeras),
  // //     tecnicos: Number(rawValues.tecnicos),
  // //     pediatra: Number(rawValues.pediatra),
  // //     gineco_obstetra: Number(rawValues.gineco_obstetra),
  // //     anestesiologo: Number(rawValues.anestesiologo),
  // //     cirujano_general: Number(rawValues.cirujano_general),
  // //     intensivista: Number(rawValues.intensivista),
  // //     internista: Number(rawValues.internista),
  // //     cardiologo: Number(rawValues.cardiologo),
  // //     traumatologo: Number(rawValues.traumatologo),
  // //     otros_especialistas: Number(rawValues.otros_especialistas),

  // //     // Epidemiología
  // //     anho_epi: Number(rawValues.anho_epi),
  // //     semana_epi: Number(rawValues.semana_epi),
  // //     casos_dengue: Number(rawValues.casos_dengue),
  // //     casos_anemia: Number(rawValues.casos_anemia),
  // //     mort_materna: Number(rawValues.mort_materna),
  // //     casos_desnutricion: Number(rawValues.casos_desnutricion),
  // //     iras_edas: Number(rawValues.iras_edas),
  // //     mortalidad_neonatal: Number(rawValues.mortalidad_neonatal),

  // //     // Servicios
  // //     emergencia: Boolean(rawValues.emergencia),
  // //     uci: Boolean(rawValues.uci),
  // //     centro_quirurgico: Boolean(rawValues.centro_quirurgico),
  // //     partos: Boolean(rawValues.partos),
  // //     consultas_diarias_prom: Number(rawValues.consultas_diarias_prom),
  // //     camas_ocupadas: Number(rawValues.camas_ocupadas),

  // //     // Condiciones Básicas
  // //     agua: Boolean(rawValues.agua),
  // //     desague: Boolean(rawValues.desague),
  // //     electricidad: Boolean(rawValues.electricidad),
  // //     oxigeno: Boolean(rawValues.oxigeno),
  // //     internet: Boolean(rawValues.internet),

  // //     // Común
  // //     fecha_corte: new Date(rawValues.fecha_corte!)
  // //   };

  // //   this.saludService.guardarReporteSalud(dto)
  // //     .subscribe({
  // //       next: (resp) => {
  // //         console.log(resp);
  // //         alert("Reporte registrado correctamente.");
  // //         this.limpiarFormulario();
  // //       },
  // //       error: (err) => {
  // //         console.error(err);
  // //         alert("Error al registrar el reporte.");
  // //       }
  // //     });
  }

  
  limpiarFormulario(): void {

    this.form.reset({

      id_renaes: '',

      nombre_eess: '',

      categoria: '',

      red_salud: '',

      microred: '',

      provincia: '',

      distrito: '',

      tipo: '',

      coord_lat: 0,

      coord_long: 0,

      poblacion_asignada: 0,

      id_proyecto: 0,

      estado_inversion: '',

      avance_fisico: 0,

      avance_financiero: 0,

      monto_total: 0,

      monto_devengado: 0,

      unidad_ejecutora: '',

      camas_uci_tot: 0,

      camas_uci_disp: 0,

      camas_hospitalarias: 0,

      equipo_rayos_x: false,

      planta_oxigeno: false,

      estado_infra: 1,

      ventiladores: 0,

      monitores: 0,

      ecografo: false,

      tomografo: false,

      operativo: 0,

      inoperativo: 0,

      med_prog: 0,

      med_exist: 0,

      turno_24h: false,

      enfermeras: 0,

      tecnicos: 0,

      pediatra: 0,

      gineco_obstetra: 0,

      anestesiologo: 0,

      cirujano_general: 0,

      intensivista: 0,

      internista: 0,

      cardiologo: 0,

      traumatologo: 0,

      otros_especialistas: 0,

      anho_epi: new Date().getFullYear(),

      semana_epi: 1,

      casos_dengue: 0,

      casos_anemia: 0,

      mort_materna: 0,

      casos_desnutricion: 0,

      iras_edas: 0,

      mortalidad_neonatal: 0,

      emergencia: false,

      uci: false,

      centro_quirurgico: false,

      partos: false,

      consultas_diarias_prom: 0,

      camas_ocupadas: 0,

      agua: false,

      desague: false,

      electricidad: false,

      oxigeno: false,

      internet: false,

      fecha_corte: ''

    });

  }
}
