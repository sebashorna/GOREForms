import { prisma } from "../../config/prisma";
import { CrearSaludDTO } from "./dto/crearSalud.dto";
import { Prisma } from "@prisma/client";

class SaludRepository {

    async findAll() {
        return prisma.establecimientos.findMany({
            orderBy: {
                nombre_eess: "asc"
            }
        });
    }

    async findById(idRenaes: number) {
        return prisma.establecimientos.findUnique({
            where: {
                id_renaes: idRenaes
            }
        });
    }

    async create(dto: CrearSaludDTO) {

        return prisma.$transaction(async (tx) => {

            await this.actualizarEstablecimiento(tx, dto);

            //await this.guardarProyecto(tx, dto);

            await this.guardarEquipamiento(tx, dto);

            await this.guardarRecursosHumanos(tx, dto);

            await this.guardarEpidemiologia(tx, dto);

            //await this.guardarServicios(tx, dto);

            //await this.guardarCondiciones(tx, dto);

            return {

                success: true,
                message: "Reporte registrado correctamente."

            };

        });

    }

    private async actualizarEstablecimiento(

        tx: Prisma.TransactionClient,

        dto: CrearSaludDTO

    ) {

        await tx.establecimientos.update({

            where: {

                id_renaes: dto.id_renaes

            },

            data: {

                poblacion_asignada: dto.poblacion_asignada,

                coord_lat: dto.coord_lat,

                coord_long: dto.coord_long

            }

        });

    }

    private async guardarEquipamiento(

        tx: Prisma.TransactionClient,

        dto: CrearSaludDTO

    ) {

        await tx.equipamiento_estado.create({

            data: {

                id_renaes: dto.id_renaes,

                camas_uci_tot: dto.camas_uci_tot,

                camas_uci_disp: dto.camas_uci_disp,

                camas_hospitalarias: dto.camas_hospitalarias,

                equipo_rayos_x: dto.equipo_rayos_x,

                planta_oxigeno: dto.planta_oxigeno,

                estado_infra: dto.estado_infra,

                ventiladores: dto.ventiladores,

                monitores: dto.monitores,

                ecografo: dto.ecografo,

                tomografo: dto.tomografo,

                operativo: dto.operativo,

                inoperativo: dto.inoperativo,

                fecha_corte: dto.fecha_corte

            }

        });

    }

    private async guardarRecursosHumanos(

        tx: Prisma.TransactionClient,

        dto: CrearSaludDTO

    ) {

        await tx.recursos_humanos.create({

            data: {

                id_renaes: dto.id_renaes,

                med_prog: dto.med_prog,

                med_exist: dto.med_exist,

                turno_24h: dto.turno_24h,

                enfermeras: dto.enfermeras,

                tecnicos: dto.tecnicos,

                pediatra: dto.pediatra,

                gineco_obstetra: dto.gineco_obstetra,

                anestesiologo: dto.anestesiologo,

                cirujano_general: dto.cirujano_general,

                intensivista: dto.intensivista,

                internista: dto.internista,

                cardiologo: dto.cardiologo,

                traumatologo: dto.traumatologo,

                otros_especialistas: dto.otros_especialistas,

                fecha_corte: dto.fecha_corte

            }

        });

    }

    private async guardarEpidemiologia(

        tx: Prisma.TransactionClient,

        dto: CrearSaludDTO

    ) {

        await tx.epidemiologia.create({

            data: {

                id_renaes: dto.id_renaes,

                anho_epi: dto.anho_epi,

                semana_epi: dto.semana_epi,

                casos_dengue: dto.casos_dengue,

                casos_anemia: dto.casos_anemia,

                mort_materna: dto.mort_materna,

                casos_desnutricion: dto.casos_desnutricion,

                iras_edas: dto.iras_edas,

                mortalidad_neonatal: dto.mortalidad_neonatal,

                fecha_corte: dto.fecha_corte

            }

        });

    }


}

export default new SaludRepository();